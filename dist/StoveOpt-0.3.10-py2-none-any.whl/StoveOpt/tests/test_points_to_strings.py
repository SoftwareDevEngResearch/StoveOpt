# -*- coding: utf-8 -*-
"""
Created on Mon May 13 18:14:56 2019

@author: Lee
"""

# Ensure points_to_strings() function will output coordinates of string type, and max length 5



