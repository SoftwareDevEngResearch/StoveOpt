# -*- coding: utf-8 -*-
"""
Created on Tue Apr 23 10:12:40 2019

@author: Lee
"""

# Goal is to make sure that the fuel vertices are the following:
# type = str
# max length = 3x4 (3 coords), + 2(spaces) + 2 parens = 16







