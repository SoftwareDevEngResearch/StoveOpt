# -*- coding: utf-8 -*-
"""
Created on Tue May 14 10:22:45 2019

@author: Lee
"""
__version_info__ = (0, 3, 10)
__version__ = '.',join(map(str,__version_info__[:3]))
if len(__version_info__) == 4:
    __version__+=__version_info[-1]
    
    
